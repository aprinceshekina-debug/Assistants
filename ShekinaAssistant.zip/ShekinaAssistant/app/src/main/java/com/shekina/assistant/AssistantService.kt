package com.shekina.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo as N

class AssistantService : AccessibilityService() {
    companion object { var inst: AssistantService? = null }
    override fun onServiceConnected() { inst = this }
    override fun onUnbind(i: Intent?): Boolean { inst = null; return super.onUnbind(i) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun clickText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(t)) {
            var c: N? = n
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.performAction(N.ACTION_CLICK)) return true
        }
        return false
    }
    fun readScreen(): String {
        val sb = StringBuilder()
        fun walk(n: N?) { if (n == null || sb.length > 500) return
            n.text?.let { sb.append(it).append(". ") }
            for (i in 0 until n.childCount) walk(n.getChild(i)) }
        walk(rootInActiveWindow)
        return sb.toString().ifBlank { "Je ne vois aucun texte à l'écran." }
    }
    fun scroll(forward: Boolean): Boolean {
        fun find(n: N?): N? { if (n == null) return null; if (n.isScrollable) return n
            for (i in 0 until n.childCount) find(n.getChild(i))?.let { return it }; return null }
        return find(rootInActiveWindow)?.performAction(if (forward) N.ACTION_SCROLL_FORWARD else N.ACTION_SCROLL_BACKWARD) ?: false
    }
    fun type(t: String): Boolean {
        val f = rootInActiveWindow?.findFocus(N.FOCUS_INPUT) ?: return false
        return f.performAction(N.ACTION_SET_TEXT, Bundle().apply { putCharSequence(N.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t) })
    }
    fun global(a: Int) = performGlobalAction(a)
}
