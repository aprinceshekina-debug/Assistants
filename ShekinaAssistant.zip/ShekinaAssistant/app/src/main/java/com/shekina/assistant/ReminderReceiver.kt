package com.shekina.assistant

import android.app.*
import android.content.*

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("rappels", "Rappels", NotificationManager.IMPORTANCE_HIGH))
        val n = Notification.Builder(c, "rappels").setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Rappel").setContentText(i.getStringExtra("t") ?: "").setAutoCancel(true)
            .setContentIntent(PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)).build()
        nm.notify((System.currentTimeMillis() % 100000).toInt(), n)
    }
}
