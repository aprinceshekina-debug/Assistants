package com.shekina.assistant

import android.accessibilityservice.AccessibilityService
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.*
import android.provider.*
import android.speech.*
import android.speech.tts.*
import android.telephony.SmsManager
import java.text.SimpleDateFormat
import java.util.*

class ListenService : Service(), TextToSpeech.OnInitListener {
    companion object { var running = false; var inst: ListenService? = null }
    private lateinit var tts: TextToSpeech
    private var sr: SpeechRecognizer? = null
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("notes", MODE_PRIVATE) }
    private var awakeUntil = 0L
    private var pending: (() -> Unit)? = null
    private var speaking = false
    private var torch = false
    private val wake = listOf("shékina", "shekina", "chékina", "chekina", "sekina")

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate(); running = true; inst = this
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ecoute", "Écoute", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "ecoute").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Shékina écoute").setContentText("Dis « Shékina » puis ta commande").setOngoing(true)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        tts = TextToSpeech(this, this)
    }

    override fun onInit(s: Int) {
        tts.language = Locale.FRENCH
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { speaking = true }
            override fun onDone(id: String?) { speaking = false }
            override fun onError(id: String?) { speaking = false }
        })
        listen()
    }

    fun announce(t: String) { say(t) }
    private fun go(i: Intent) { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    private fun say(t: String) { tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "x") }
    private fun ask(q: String, ok: () -> Unit) { pending = ok; awakeUntil = System.currentTimeMillis() + 10000; say(q) }

    private fun listen() {
        if (!running) return
        if (speaking) { ui.postDelayed({ listen() }, 500); return }
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle) {
                    r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { onHeard(it.lowercase(Locale.FRENCH)) }
                    ui.postDelayed({ listen() }, 400)
                }
                override fun onError(e: Int) { ui.postDelayed({ listen() }, 800) }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            })
        }
    }

    private fun onHeard(t: String) {
        val now = System.currentTimeMillis()
        val p = pending
        if (p != null) {
            if (now > awakeUntil) pending = null
            else {
                if (listOf("oui", "confirme", "vas-y", "ok").any { t.contains(it) }) { pending = null; p() }
                else if (listOf("non", "annule", "stop").any { t.contains(it) }) { pending = null; say("Annulé.") }
                return
            }
        }
        val w = wake.firstOrNull { t.contains(it) }
        if (w != null) {
            val rest = t.substringAfter(w).trim(); awakeUntil = now + 8000
            if (rest.isEmpty()) say("Je t'écoute.") else handle(rest)
        } else if (now < awakeUntil) { awakeUntil = now + 8000; handle(t) }
    }

    private var m: MatchResult? = null
    private fun hit(t: String, p: String): Boolean { m = Regex(p).find(t); return m != null }
    private fun acc() = AssistantService.inst
    private fun needAcc(f: (AssistantService) -> Unit) {
        val a = acc() ?: run { say("Active d'abord l'accessibilité, je t'ouvre les réglages."); go(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return }
        f(a)
    }

    private fun handle(t: String) {
        when {
            t.contains("aide") -> say("Appels, SMS, applis, lampe, volume, alarme, minuteur, rappels, notes, appels manqués, messages, et contrôle de l'écran : retour, accueil, clique sur, défile, écris, lis l'écran.")
            hit(t, "rappelle-moi dans (\\d+) (minute|heure)s?(?: de | d'| que )?(.*)") -> remind(System.currentTimeMillis() + m!!.groupValues[1].toLong() * (if (m!!.groupValues[2] == "heure") 3600000L else 60000L), m!!.groupValues[3])
            hit(t, "rappelle-moi à (\\d{1,2}) heures?(?: (\\d{1,2}))?(?: de | d'| que )?(.*)") -> {
                val c = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, m!!.groupValues[1].toInt()); set(Calendar.MINUTE, m!!.groupValues[2].ifEmpty { "0" }.toInt()); set(Calendar.SECOND, 0); if (timeInMillis < System.currentTimeMillis()) add(Calendar.DAY_OF_MONTH, 1) }
                remind(c.timeInMillis, m!!.groupValues[3]) }
            t.contains("appels manqués") || t.contains("appel manqué") -> missed()
            t.contains("lis mes messages") || t.contains("mes sms") || t.contains("derniers messages") -> readSms()
            t.contains("lis l'écran") || t.contains("lis l'ecran") -> needAcc { say(it.readScreen()) }
            t.contains("retour") -> needAcc { it.global(AccessibilityService.GLOBAL_ACTION_BACK) }
            t.contains("accueil") -> needAcc { it.global(AccessibilityService.GLOBAL_ACTION_HOME) }
            t.contains("récentes") || t.contains("recentes") -> needAcc { it.global(AccessibilityService.GLOBAL_ACTION_RECENTS) }
            t.contains("notifications") -> needAcc { it.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS) }
            hit(t, "(?:clique|appuie|touche)(?: sur)? (.+)") -> needAcc { if (!it.clickText(m!!.groupValues[1])) say("Je ne vois pas « ${m!!.groupValues[1]} » à l'écran.") }
            t.contains("défile vers le bas") || t.contains("descends") -> needAcc { it.scroll(true) }
            t.contains("défile vers le haut") || t.contains("remonte") -> needAcc { it.scroll(false) }
            hit(t, "écris (.+)") -> needAcc { if (!it.type(m!!.groupValues[1])) say("Aucun champ de texte sélectionné.") }
            hit(t, "(?:appelle|appeler) (.+)") -> call(m!!.groupValues[1])
            hit(t, "sms (?:à|a) (.+?) (?:disant|message) (.+)") -> sms(m!!.groupValues[1], m!!.groupValues[2])
            hit(t, "(?:ouvre|lance) (.+)") -> openApp(m!!.groupValues[1])
            t.contains("lampe") || t.contains("torche") -> flash(!t.contains("éteins") && !t.contains("coupe"))
            t.contains("volume") && t.contains("monte") -> vol(AudioManager.ADJUST_RAISE)
            t.contains("volume") && (t.contains("baisse") || t.contains("diminue")) -> vol(AudioManager.ADJUST_LOWER)
            hit(t, "minuteur.*?(\\d+)\\s*(minute|min|seconde|heure)") -> timer(m!!)
            hit(t, "alarme.*?(\\d{1,2})\\s*(?:h|heures?)\\s*(\\d{1,2})?") -> alarm(m!!)
            hit(t, "(?:note|retiens) (?:que )?(.+)") -> note(m!!.groupValues[1])
            t.contains("mes notes") -> say(prefs.getStringSet("n", emptySet())!!.joinToString(". ").ifEmpty { "Aucune note." })
            t.contains("heure") -> say("Il est " + SimpleDateFormat("HH 'heures' mm", Locale.FRENCH).format(Date()))
            t.contains("wifi") -> go(Intent(Settings.ACTION_WIFI_SETTINGS))
            t.contains("bluetooth") -> go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            else -> say("Je n'ai pas compris. Dis « aide ».")
        }
    }

    private fun remind(at: Long, what: String) {
        val txt = what.ifBlank { "Rappel" }
        Reminders.add(this, at, txt)
        say("C'est noté : " + SimpleDateFormat("HH:mm", Locale.FRENCH).format(Date(at)) + ", $txt.")
    }
    private fun missed() {
        val c = contentResolver.query(CallLog.Calls.CONTENT_URI, arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME),
            "${CallLog.Calls.TYPE}=?", arrayOf(CallLog.Calls.MISSED_TYPE.toString()), "${CallLog.Calls.DATE} DESC")
        val l = mutableListOf<String>()
        c?.use { while (it.moveToNext() && l.size < 5) l.add(it.getString(1) ?: it.getString(0)) }
        say(if (l.isEmpty()) "Aucun appel manqué." else "Appels manqués : " + l.joinToString(", "))
    }
    private fun readSms() {
        val c = contentResolver.query(Telephony.Sms.Inbox.CONTENT_URI, arrayOf("address", "body"), null, null, "date DESC")
        val l = mutableListOf<String>()
        c?.use { while (it.moveToNext() && l.size < 3) l.add("de " + it.getString(0) + " : " + it.getString(1)) }
        say(if (l.isEmpty()) "Aucun message." else l.joinToString(". "))
    }

    private fun contactNumber(name: String): String? {
        if (name.any { it.isDigit() }) return name.filter { it.isDigit() || it == '+' }
        val c = contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null)
        return c?.use { if (it.moveToFirst()) it.getString(0) else null }
    }
    private fun call(who: String) {
        val n = contactNumber(who) ?: return say("Je ne trouve pas $who.")
        ask("Je dois appeler $who. Tu confirmes ?") { go(Intent(Intent.ACTION_CALL, Uri.parse("tel:$n"))) }
    }
    private fun sms(who: String, msg: String) {
        val n = contactNumber(who) ?: return say("Je ne trouve pas $who.")
        ask("J'envoie à $who : $msg. Tu confirmes ?") { SmsManager.getDefault().sendTextMessage(n, null, msg, null, null); say("Message envoyé à $who.") }
    }
    private fun openApp(name: String) {
        val pm = packageManager
        val app = pm.getInstalledApplications(0).firstOrNull { pm.getApplicationLabel(it).toString().lowercase(Locale.FRENCH).contains(name.trim()) }
        val i = app?.let { pm.getLaunchIntentForPackage(it.packageName) } ?: return say("Application $name introuvable.")
        say("J'ouvre $name"); go(i)
    }
    private fun flash(on: Boolean) {
        val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        try { cm.setTorchMode(cm.cameraIdList[0], on); torch = on; say(if (on) "Lampe allumée." else "Lampe éteinte.") } catch (e: Exception) { say("Lampe indisponible.") }
    }
    private fun vol(d: Int) { (getSystemService(Context.AUDIO_SERVICE) as AudioManager).adjustStreamVolume(AudioManager.STREAM_MUSIC, d, AudioManager.FLAG_SHOW_UI); say("D'accord.") }
    private fun timer(m: MatchResult) {
        val n = m.groupValues[1].toInt(); val u = m.groupValues[2]
        val s = when { u.startsWith("h") -> n * 3600; u.startsWith("m") -> n * 60; else -> n }
        go(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, s).putExtra(AlarmClock.EXTRA_SKIP_UI, true)); say("Minuteur lancé.")
    }
    private fun alarm(m: MatchResult) {
        go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, m.groupValues[1].toInt())
            .putExtra(AlarmClock.EXTRA_MINUTES, m.groupValues[2].ifEmpty { "0" }.toInt()).putExtra(AlarmClock.EXTRA_SKIP_UI, true)); say("Alarme réglée.")
    }
    private fun note(t: String) { val s = prefs.getStringSet("n", emptySet())!!.toMutableSet(); s.add(t); prefs.edit().putStringSet("n", s).apply(); say("Noté.") }

    override fun onDestroy() { running = false; inst = null; sr?.destroy(); tts.shutdown(); super.onDestroy() }
}
