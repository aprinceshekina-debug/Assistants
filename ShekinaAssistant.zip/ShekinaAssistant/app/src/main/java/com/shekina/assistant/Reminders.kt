package com.shekina.assistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.*

object Reminders {
    fun add(c: Context, at: Long, text: String) {
        val p = c.getSharedPreferences("rem", 0)
        val s = p.getStringSet("r", emptySet())!!.toMutableSet(); s.add("$at|$text")
        p.edit().putStringSet("r", s).apply(); schedule(c, at, text)
    }
    fun schedule(c: Context, at: Long, text: String) {
        val pi = PendingIntent.getBroadcast(c, (at % 1000000).toInt(), Intent(c, ReminderReceiver::class.java).putExtra("t", text),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
    }
    fun restore(c: Context) {
        val p = c.getSharedPreferences("rem", 0); val now = System.currentTimeMillis()
        val keep = p.getStringSet("r", emptySet())!!.filter { (it.substringBefore("|").toLongOrNull() ?: 0) > now }.toSet()
        p.edit().putStringSet("r", keep).apply()
        keep.forEach { schedule(c, it.substringBefore("|").toLong(), it.substringAfter("|")) }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Reminders.restore(c) }
}
