package com.shekina.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    private val perms = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS,
        Manifest.permission.SEND_SMS, Manifest.permission.CAMERA, Manifest.permission.READ_CALL_LOG,
        Manifest.permission.READ_SMS, Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.READ_PHONE_STATE)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        val st = TextView(this).apply { textSize = 17f; setPadding(0, 0, 0, 32) }
        fun refresh() { st.text = if (ListenService.running) "🟢 Shékina écoute en arrière-plan.\nDis « Shékina » puis ta commande." else "⚪ Arrêté." }
        fun btn(l: String, f: () -> Unit) = Button(this).apply { text = l; setOnClickListener { f() } }
        root.addView(st)
        root.addView(btn("▶ Démarrer / ⏹ arrêter l'écoute") {
            if (ListenService.running) stopService(Intent(this, ListenService::class.java))
            else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) requestPermissions(perms, 1)
            else startForegroundService(Intent(this, ListenService::class.java))
            st.postDelayed({ refresh() }, 600)
        })
        root.addView(btn("1. Autoriser l'affichage par-dessus") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) })
        root.addView(btn("2. Activer l'accessibilité") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(btn("3. Ne pas optimiser la batterie") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) })
        setContentView(root); refresh()
        requestPermissions(perms, 1)
    }
}
