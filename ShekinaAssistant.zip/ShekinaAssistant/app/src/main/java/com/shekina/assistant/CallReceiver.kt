package com.shekina.assistant

import android.app.*
import android.content.*
import android.net.Uri
import android.provider.ContactsContract
import android.telephony.TelephonyManager

class CallReceiver : BroadcastReceiver() {
    companion object { var last = ""; var lastT = 0L }

    override fun onReceive(c: Context, i: Intent) {
        if (i.getStringExtra(TelephonyManager.EXTRA_STATE) != TelephonyManager.EXTRA_STATE_RINGING) return
        val n = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: return
        val now = System.currentTimeMillis()
        if (n == last && now - lastT < 15000) return
        last = n; lastT = now
        if (known(c, n)) return
        val foreign = n.startsWith("+") && !n.startsWith("+228")
        val msg = if (foreign) "Attention, appel d'un numéro étranger inconnu : $n" else "Appel d'un numéro inconnu : $n"
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("alertes", "Alertes", NotificationManager.IMPORTANCE_HIGH))
        nm.notify(7, Notification.Builder(c, "alertes").setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(if (foreign) "⚠️ Numéro étranger inconnu" else "Numéro inconnu").setContentText(n).setAutoCancel(true).build())
        ListenService.inst?.announce(msg)
    }

    private fun known(c: Context, n: String): Boolean {
        val u = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(n))
        return c.contentResolver.query(u, arrayOf(ContactsContract.PhoneLookup._ID), null, null, null)?.use { it.count > 0 } ?: false
    }
}
